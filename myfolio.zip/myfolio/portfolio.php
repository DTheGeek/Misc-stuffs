<html>
    <head>
        <title>
            My Portfolio
        </title>
        <style>
        
        @media screen(min-width:768px) {
            .ex {
                width: 250px;
            }
            
            .cert {
                width:250px;
                height: 250px;
            }
            #desc {
                font-size: 22px;
            }
        }
        
        
           #main {
            background:#fff;
           }
           
           #desc {
               text-align:center;
               margin: auto 10%;
               padding: 0px;
           }
           
           #p-img {
               margin: 10% auto;
           }
           
           .work {
               /*text-align: center;*/
               height: auto;
               margin: 5%;
               display: flex;
               /*flex-flow: row wrap;*/
               flex-wrap: wrap;
               justify-content: flex-start;
               align-items: center;
           }
           
           .work a {
               color: #7ac;
               text-decoration: none;
           }
           
           .ex {
               margin: 35px;
           }
           
           .title {
               display: block;
               margin: 5% auto;
           }
           
           .ex {
               width: 200px;
               /*max-width: 250px;*/
               height:200px;
               transition: transform 0.5s;
           }
           
           .cert {
               width: 200px;
               height: 200px;
               border: 2px solid #4ac;
               border-radius: 9px;
           }
           
           .cert:hover {
               transform: rotate(-20deg);
           }
           
        </style>
    </head>
    <body>
        <?php 
        include 'header.php';
        ?>
        <div id='main' class='col-12'>
            
            <div class='cont' id='desc'>
                <img id='p-img' src='folio.png' height='30px'>
                <div>
                Vous trouverez ici les certificats que j'ai obtenus dans le domaine de la programmation ainsi que certains des projets récents sur lesquels j'ai travaillé. À noter que la liste n'est pas exhaustive...
                </div>
            </div>
 
            <img class='title' height='18px' src='real.png'>
                
            <div class='work'>
               
            <p class='ex'>
                <img class='cert' src="doosnet.png" loading='lazy'><br/>
                <a href='https://doofall.ddns.net'>Le blog de doodoo</a>
            </p>
            <p class='ex'>
                <img class='cert' src="scalc.png" loading='lazy'>
                <br/>
                <a href='https://www.w3schools.com/code/tryit.asp?filename=GSZG3M9KT6QZ'>
                 SimpleCalc (programme de calculatrice..)
                </a>
            </p>
            <p class='ex'>
                <img class='cert' src="ggame.png" loading='lazy'>
                <br/>
                <a href="https://www.w3schools.com/code/tryit.asp?filename=GSWNFI5RTLKE">GuessGame(jeu de devinette numérique)</a>
            </p>
            <p class='ex'>
                <img class='cert' src="beasy.png" loading='lazy'>
                <br/>
                <a href="doofall.ddns.net/beasy.hml">
                    Blueasy (Maquette de site générique)
                </a>
            </p>
            </div>
            <img class='title' height='18px' src='certif.png'>
            <div class='work'>

                
                <p class='ex'>
                    <img class='cert' src='images/css-certif.jpeg'>
                    <a hef='#'>Certificat CSS</a>
                </p>
                <p class='ex'>
                    <img class='cert' src='images/html-certif.jpeg'>
                    <a hef='#'>Certificat HTML</a>
                </p>
                <p class='ex'>
                    <img class='cert' src='images/js-certif.jpeg'>
                    <a hef='#'>Certificat JavaScript</a>
                </p>
                <p class='ex'>
                    <img class='cert' src='images/php-certif.jpeg'>
                    <a hef='#'>Certificat PHP</a>
                </p>
                <p class='ex'>
                    <img class='cert' src='images/sql-certif.jpeg'>
                    <a href='#'>Certificat SQL</a>
                </p>
            </div>
        </div>
        <?php 
        include 'footer.php'
        ?>
    </body>
</html>