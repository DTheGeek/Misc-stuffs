<html>
    <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
#footer {
    min-height:65px;
    position:relative;
    top:30px;
    color:#f92;
    padding:5px;
    text-align:center;
    border-top:5px solid #fee;
}

i {
    padding:5px;
}

#footer a {
    color:#f92;
}

.fa-comment {
    
}

.fa-whatsapp {
    
}

.fa-soundcloud {
    
}
        </style>
    </head>
        <body>
    <div id="footer">
    <a href="sms:707274945?">
    <i class="fa fa-comment"> Text me |</i>
    </a>
    <a href="https://api.whatsapp.com/send?phone=&text=Hello%21%20Voici%20un%20site%20très%20interessant%3A%20doofall%2Eddns%2Enet">
    <i class="fa fa-whatsapp">Whatsapp | </i>
    </a>
    <a href="https://youtube.com/channel/UCmLSL6ub86BFHnzATzUVCcw">
    <i class="fa fa-youtube">Youtube</i>
    </a>
    <p>&#169; <?php echo date("Y") ?> Doos Inc. All rights will be reserved! v1.0
    </p>
    <?php
    $time = date("Y/m/d");
    echo $time
    ?>
    </div>
        </body>
</html>