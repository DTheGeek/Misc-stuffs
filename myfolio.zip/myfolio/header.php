<html>
    <head>
    <meta name="viewport" content="width=device-width,initial-scale=1.0" user-scalable="no">
    <link rel="icon" href="images/page-icon.jpeg">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'> 
    <script src="https://code.jquery.com/jquery-3.1.1.js">
</script>
    <style>
    
    * {
    font:13px "Roboto";
    box-sizing:border-box;
    margin:0px 0px 0px 0px;
        }

    
/*For phones and tablets*/
@media only screen and (max-width:640px) {
    
    body {
      
    }
    
    a {
        text-decoration:none;

    }

    #header {
        max-height:25%;
    }

    #nav {
    position:relative;
    text-align: center;
    display:none;
    float: none;
    background:#f1f1f1;
    transition:1s;
    }

    #nav a {
    text-decoration:none;
    display:block;
    font-size:16px;
    padding:10px;
    color:#000;
    }

    #nav-btn {
    float:right;
    font-size:18px;
    font-weight:900;
    transition:1s;
    }

}



/*For desktop & laptops*/
@media only screen and (min-width:992px) {
    
    body {
        
    }

    .col-1 {
        width: 8.33%;
        float: left;
    }
    
    .col-2 {
        width: 16.66%;
        float: left;
    }
    
    .col-3 {
        width: 25%;
        float: left;
    }
    
    .col-6 {
        width: 50%;
        float: left;
    }
    
    .col-11 {
        width: 91.66%;
        float: left;
    }
    
    .col-12 {
        width: 100%;
        float: left;
    }
    
    #header {
        max-height: 25%;
        background: #f1f1f1;
    }
    
    
    #nav-btn {
        display: none;
    }
    
    #nav {
        display: /*column*/;
        padding:0%;
        text-align: center;
    }
    
    #nav a {
        display: inline-block;
        text-decoration:none;
        color:#000;
        padding:14px;
        
    }
    
    #nav a:hover {
        background: rgba(245,181,27,1);
    }
    
    #langList {
        position: absolute;
        left: 25%;
        top: 5%;
        padding:0%;
        display: none;
    }
    
    #nav #langList a {
        padding: 15px;
        display: block;
    }
    
}


/*For landscape tablets
@media (orientation:landscape) {

}*/
        

        
    </style>
    </head>

        <div id="header" class="col-12">
        <!--<a href="http://doofall.ddns.net" class="col-1">
        <img id="logo" height="18px" src="images/new-logo.png" alt="doos-logo@18px">
        </a> -->
        <span id="nav-btn" onclick="toggleNav()" > &#8230;</span>
    <!-- navigation bar--->
        <div id="nav" class="col-11">
            <a href="#" onclick="toggleNav()" >&#8230;</a>
            <a href="index.php" class="col-1">Coding </a>
            <a href="#" onclick="showBox()" class="col-1">Art</a>
            <a href="portfolio.php" onclick="showBox()" class="col-1">Portfolio</a>
            <a href="#" id="lang-btn" onclick="selectLang()" class="col-1">Language</a>
    <!-- languages list --->
            <div id="langList">
            <a href="#">Wolof</a>
            <a href="#">English</a>
            <a href="#">French</a>
            </div>
            <a href="/account.php" class="col-1">Sign up/Log in</a>
            
        </div>
        </div>

    <script>

var lang = document.getElementById("langList");
var btn = document.getElementById("nav-btn");
    function toggleNav () {
    var nav = document.getElementById("nav");
    lang.style.display = "none";

    if (nav.style.display === "none") {
        nav.style.display = "block";
    //    btn.style.transform = "rotate(90deg)";
        }
    else {
    nav.style.display = "none";
    //btn.style.transform = "rotate(-90deg)";
       }
    }
    
    function selectLang () {
    if (lang.style.display === "none") {
        lang.style.display = "block";
        lang.style.background = "#ddd";
    }
    else {
        lang.style.display = "none";
       }
    }

    </script>

</html>